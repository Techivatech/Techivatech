// Usage: https://www.chartjs.org/
import Chart from "chart.js";

Chart.defaults.global.defaultFontFamily = "'Inter', 'Helvetica Neue', 'Helvetica', 'Arial', sans-serif";
window.Chart = Chart;